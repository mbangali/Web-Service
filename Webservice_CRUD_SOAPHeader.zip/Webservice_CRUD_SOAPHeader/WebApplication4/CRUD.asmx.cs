﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml;
using System.Xml.Serialization;
using BO;

namespace WebApplication4
{
    /// <summary>
    /// Summary description for CRUD
    /// </summary>
    /// 

    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(Name = "TestService",ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class CRUD : System.Web.Services.WebService
    {

        public AuthHeader objAuthHeader;
        public CRUD()
        {
            //Uncomment the following line if using designed components 
            //InitializeComponent(); 
        }

        [WebMethod]
        [SoapDocumentMethod(Binding = "TestService")]
        [SoapHeader("objAuthHeader", Required = true)]
        public bool InsertEmployee(Employee obj)
        {

            //  objAuthHeader = new AuthHeader();
            if (objAuthHeader.username.Equals("manthan") && objAuthHeader.password.Equals("manthan"))
            {
                return obj.Insert();
            }
            return false;
        }
        [WebMethod]
        [SoapDocumentMethod(Binding = "TestService")]
        [SoapHeader("objAuthHeader", Required = true)]
        public bool UpdateEmployee(Employee obj)
        {
            // objAuthHeader = new AuthHeader();
            if (objAuthHeader.username.Equals("manthan") && objAuthHeader.password.Equals("manthan"))
            {
                return obj.Update();
            }
            return false;
        }
        [WebMethod]
        [SoapDocumentMethod(Binding = "TestService")]
        [SoapHeader("objAuthHeader", Required = true)]
        public bool DeleteEmployee(Employee obj)
        {
            // objAuthHeader = new AuthHeader();
            if (objAuthHeader.username.Equals("manthan") && objAuthHeader.password.Equals("manthan"))
            {
                return obj.Delete();
            }
            return false;
        }
        [WebMethod]
        [SoapDocumentMethod(Binding = "TestService")]
        [SoapHeader("objAuthHeader", Required = true)]
        public Employee GetEmployee(int id)
        {
            // objAuthHeader = new AuthHeader();
            if (objAuthHeader.username.Equals("manthan") && objAuthHeader.password.Equals("manthan"))
            {
                Employee obj = new Employee();
                return obj.Get(id);
            }
            return null;
        }
        [WebMethod]
        [SoapDocumentMethod(Binding = "TestService")]
        [SoapHeader("objAuthHeader", Required = true)]
        public List<Employee> GetAllEmployee()
        {
            // objAuthHeader = new AuthHeader();
            if (objAuthHeader.username.Equals("manthan") && objAuthHeader.password.Equals("manthan"))
            {
                Employee obj = new Employee();
                return obj.GetAll();
            }
            return null;
        }

        public class AuthHeader : SoapHeader
        {
            public string username = string.Empty;
            public string password = string.Empty;
        }
    }
}

//using System;
//using System.Web;
//using System.Collections;
//using System.Web.Services;
//using System.Web.Services.Protocols;

//namespace WebApplication4
//{
//    /// <summary>
//    /// Summary description for SOAPHeaderService
//    /// </summary>
//    [WebService(Namespace = "http://tempuri.org/")]
//    [WebServiceBinding(Name = "TestService", ConformsTo = WsiProfiles.BasicProfile1_1)]
//    public class SOAPHeaderService : System.Web.Services.WebService
//    {
//        // Visual studio will append a "UserCredentialsValue" property to the proxy class
//        public UserCredentials consumer;

//        public SOAPHeaderService()
//        {
//            //Uncomment the following line if using designed components 
//            //InitializeComponent(); 
//        }

//        [WebMethod]
//        [SoapDocumentMethod(Binding = "TestService")]
//        [SoapHeader("consumer", Required = true)]
//        public string GetBalance()
//        {
//            if (checkConsumer())
//                return consumer.userName + " had 10000000 credit";
//            else
//                return "Error in authentication";
//        }

//        private bool checkConsumer()
//        {
//            // In this method you can check the username and password 
//            // with your database or something
//            // You could also encrypt the password for more security
//            if (consumer != null)
//            {
//                if (consumer.userName == "Ahmed" && consumer.password == "1234")
//                    return true;
//                else
//                    return false;
//            }
//            else
//                return false;

//        }

//    }

//    # region "SOAP Headers"

//    public class UserCredentials : System.Web.Services.Protocols.SoapHeader
//    {
//        public string userName;
//        public string password;
//    }

//    # endregion

//}